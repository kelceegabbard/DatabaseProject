﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CFGUserInterface
{
    internal class RepDAO
    {
        //fake data
        //public List<Rep> reps = new List<Rep>();
        string connectionString = "datasource=localhost;port=3306;username=root;password=78jm.Lkk!1lol;database=CFG;";
        public List<Rep> getAllRep()
        {
            //start with empty list
            List<Rep> returnThese = new List<Rep>();

            //connect to swl server
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM REP", connection);

            using(MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Rep rep = new Rep
                    {
                        RepNum = reader.GetString(0),
                        LastName = reader.GetString(1),
                        FirstName = reader.GetString(2),
                        Street = reader.GetString(3),
                        City = reader.GetString(4),
                        State = reader.GetString(5),
                        PostalCode = reader.GetString(6),
                        Commission = reader.GetFloat(7),
                        Rate = reader.GetFloat(8),
                        UserName = reader.GetString(9),
                        PW = reader.GetString(10),
                    };
                    returnThese.Add(rep);
                }
            }
            connection.Close();

            return returnThese;
        }

        public bool loginCheck(String username, String password)
        {
            bool login = false;
            string connectionString = "datasource=localhost;port=3306;username=root;password=78jm.Lkk!1lol;database=CFG;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM REP", connection);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Rep rep = new Rep
                    {
                        RepNum = reader.GetString(0),
                        LastName = reader.GetString(1),
                        FirstName = reader.GetString(2),
                        Street = reader.GetString(3),
                        City = reader.GetString(4),
                        State = reader.GetString(5),
                        PostalCode = reader.GetString(6),
                        Commission = reader.GetFloat(7),
                        Rate = reader.GetFloat(8),
                        UserName = reader.GetString(9),
                        PW = reader.GetString(10),
                    };
                    if (rep.UserName == username)
                    {
                        if (rep.PW == password)
                        {
                            login = true;
                            connection.Close();
                            return login;
                        }
                    }
                }
            }
            connection.Close();
            return false;
        }

        /*
    ✓    * Login
         * Generate a report that for each representative, listing the number of customers
            assigned to the representative and the average balance of the representative’s
            customers along with the representative's first and last name; 
         * Generate a report that displays the total quoted price of all the orders from a given
            customer, taking the customer name as input;
         * Add a new representative;
         * Update a customer’s credit limit, taking the customer name as input;
    ✓    * Exit the system. 
         */

        //public
    }
}
