﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CFGUserInterface
{
    public partial class AddNewRep : Form

    {
        BindingSource repBindingSource = new BindingSource();
        public AddNewRep()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RepDAO DAOinstance = new RepDAO();



            repBindingSource.DataSource = DAOinstance.getAllRep();

            dataGridView1.DataSource = repBindingSource;
        }
    }
}
