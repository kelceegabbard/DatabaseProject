using MySql.Data.MySqlClient;

namespace CFGUserInterface
{
    public partial class Login : Form
    {
        BindingSource repBindingSource = new BindingSource();
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {




        }

        private void button2_Click(object sender, EventArgs e)
        {
            RepDAO DAOinstance = new RepDAO();
            //DAOinstance.loginCheck();
            //bool login = false;
            String name = textBox1.Text;
            String PW = textBox2.Text;
            //DAOinstance.loginCheck(name, PW);

            //Check name and Password
            /*
            string connectionString = "datasource=localhost;port=3306;username=root;password=78jm.Lkk!1lol;database=CFG;";
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT  FROM REP", connection);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Rep rep = new Rep
                    {
                        /*RepNum = reader.GetString(0),
                        LastName = reader.GetString(1),
                        FirstName = reader.GetString(2),
                        Street = reader.GetString(3),
                        City = reader.GetString(4),
                        State = reader.GetString(5),
                        PostalCode = reader.GetString(6),
                        Commission = reader.GetFloat(7),
                        Rate = reader.GetFloat(8),
                        UserName = reader.GetString(9),
                        PW = reader.GetString(10),
                    };
                    if(rep.UserName == name)
                    {
                        if(rep.PW == PW)
                        {
                            login = true;
                            
                        }
                    }
                }
            } */
            System.Diagnostics.Debugger.Break();
            if (DAOinstance.loginCheck(name, PW) == true)
            {
                Menu f2 = new Menu();
                f2.Show();
            }
            //connection.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Menu f2 = new Menu();
            f2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            RepDAO DAOinstance = new RepDAO();
            String name = textBox1.Text;
            String PW = textBox2.Text;

            //System.Diagnostics.Debugger.Break();
            if (DAOinstance.loginCheck(name, PW) == true)
            {
                Menu f2 = new Menu();
                f2.Show();
            }
        }
    }
}