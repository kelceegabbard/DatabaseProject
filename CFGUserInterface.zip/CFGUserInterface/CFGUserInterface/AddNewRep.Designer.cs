﻿namespace CFGUserInterface
{
    partial class AddNewRep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            button1 = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox5 = new TextBox();
            label5 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox8 = new TextBox();
            label8 = new Label();
            textBox9 = new TextBox();
            label9 = new Label();
            textBox10 = new TextBox();
            label10 = new Label();
            textBox11 = new TextBox();
            label11 = new Label();
            textBox12 = new TextBox();
            label12 = new Label();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(412, 39);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.RowTemplate.Height = 41;
            dataGridView1.Size = new Size(1265, 680);
            dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(44, 665);
            button1.Name = "button1";
            button1.Size = new Size(314, 46);
            button1.TabIndex = 1;
            button1.Text = "Add New Representative";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 109);
            label1.Name = "label1";
            label1.Size = new Size(107, 32);
            label1.TabIndex = 2;
            label1.Text = "RepNum";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(158, 109);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(200, 39);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(158, 154);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(200, 39);
            textBox2.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 154);
            label2.Name = "label2";
            label2.Size = new Size(107, 32);
            label2.TabIndex = 4;
            label2.Text = "RepNum";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(158, 199);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(200, 39);
            textBox3.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 199);
            label3.Name = "label3";
            label3.Size = new Size(107, 32);
            label3.TabIndex = 6;
            label3.Text = "RepNum";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(158, 244);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(200, 39);
            textBox4.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 244);
            label4.Name = "label4";
            label4.Size = new Size(107, 32);
            label4.TabIndex = 8;
            label4.Text = "RepNum";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(158, 289);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(200, 39);
            textBox5.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(44, 289);
            label5.Name = "label5";
            label5.Size = new Size(107, 32);
            label5.TabIndex = 10;
            label5.Text = "RepNum";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(158, 334);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(200, 39);
            textBox6.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(44, 334);
            label6.Name = "label6";
            label6.Size = new Size(107, 32);
            label6.TabIndex = 12;
            label6.Text = "RepNum";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(158, 604);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(200, 39);
            textBox7.TabIndex = 25;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(44, 604);
            label7.Name = "label7";
            label7.Size = new Size(107, 32);
            label7.TabIndex = 24;
            label7.Text = "RepNum";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(158, 559);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(200, 39);
            textBox8.TabIndex = 23;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(44, 559);
            label8.Name = "label8";
            label8.Size = new Size(107, 32);
            label8.TabIndex = 22;
            label8.Text = "RepNum";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(158, 514);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(200, 39);
            textBox9.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(44, 514);
            label9.Name = "label9";
            label9.Size = new Size(107, 32);
            label9.TabIndex = 20;
            label9.Text = "RepNum";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(158, 469);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(200, 39);
            textBox10.TabIndex = 19;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(44, 469);
            label10.Name = "label10";
            label10.Size = new Size(107, 32);
            label10.TabIndex = 18;
            label10.Text = "RepNum";
            // 
            // textBox11
            // 
            textBox11.Location = new Point(158, 424);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(200, 39);
            textBox11.TabIndex = 17;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(44, 424);
            label11.Name = "label11";
            label11.Size = new Size(107, 32);
            label11.TabIndex = 16;
            label11.Text = "RepNum";
            // 
            // textBox12
            // 
            textBox12.Location = new Point(158, 379);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(200, 39);
            textBox12.TabIndex = 15;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(44, 379);
            label12.Name = "label12";
            label12.Size = new Size(107, 32);
            label12.TabIndex = 14;
            label12.Text = "RepNum";
            // 
            // button2
            // 
            button2.Location = new Point(44, 39);
            button2.Name = "button2";
            button2.Size = new Size(314, 46);
            button2.TabIndex = 26;
            button2.Text = "Get Rep Table";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // AddNewRep
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1718, 763);
            Controls.Add(button2);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(textBox8);
            Controls.Add(label8);
            Controls.Add(textBox9);
            Controls.Add(label9);
            Controls.Add(textBox10);
            Controls.Add(label10);
            Controls.Add(textBox11);
            Controls.Add(label11);
            Controls.Add(textBox12);
            Controls.Add(label12);
            Controls.Add(textBox6);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Name = "AddNewRep";
            Text = "AddNewRep";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox8;
        private Label label8;
        private TextBox textBox9;
        private Label label9;
        private TextBox textBox10;
        private Label label10;
        private TextBox textBox11;
        private Label label11;
        private TextBox textBox12;
        private Label label12;
        private Button button2;
    }
}